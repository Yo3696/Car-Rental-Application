package com.register;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterService2Application {

	public static void main(String[] args) {
		SpringApplication.run(RegisterService2Application.class, args);
	}

}
