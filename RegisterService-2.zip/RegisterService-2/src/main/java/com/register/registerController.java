package com.register;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.register.Model.user;
import com.register.Model.userRepository;

@RestController
public class registerController {
	
	@Autowired
	private userRepository userrepository;
	
	@RequestMapping("/check-register")
	public String registerCheck() {
		return "Check Registered!!!";
		
	}
	
	@RequestMapping("/register-user/{username}/{password}")
	public String registerUser(@PathVariable("username") String username, @PathVariable("password") String password) {
		user u = new user();
		u.setName(username);
		u.setPassword(password);
		userrepository.save(u);
		return "Successfully Registered!!!";
		
	}
	
	
	
}
