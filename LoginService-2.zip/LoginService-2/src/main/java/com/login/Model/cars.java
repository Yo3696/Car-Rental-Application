package com.login.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class cars {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String brand;
	private String fueltype;
	private String model;
	private String type;
	private String color;
	private String number;
	private int price;
	
	public cars() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}



	public String getFueltype() {
		return fueltype;
	}

	public void setFueltype(String fueltype) {
		this.fueltype = fueltype;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "cars [id=" + id + ", brand=" + brand + ", fuelType=" + fueltype + ", model=" + model + ", type=" + type
				+ ", color=" + color + ", number=" + number + ", price=" + price + "]";
	}

	public cars(String brand, String fuelType, String model, String type, String color, String number, int price) {
		super();
		this.brand = brand;
		this.fueltype = fuelType;
		this.model = model;
		this.type = type;
		this.color = color;
		this.number = number;
		this.price = price;
	}
	
	
}
