package com.login.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.login.Model.cars;
import com.login.Repository.carRepository;
import com.login.Repository.userRepository;

@Controller
public class loginController {
	@Autowired
	private userRepository userrepository;
	
	private RestTemplate resttemplate= new RestTemplate();
	
	@Autowired
	private carRepository carrepository;
	
	
	@RequestMapping("/login")
	public String hello(Model model) {
		
		return "loginpage";
	}
	
	@RequestMapping("/back")
	public String back(Model model) {
		String username = "akhil";
		List<cars> car= carrepository.findAll();
		model.addAttribute("car", car);
		model.addAttribute("username", username);
		return "homepage";
	}
	
	
	@RequestMapping("/home")
	public String homepage(@RequestParam("username") String username, @RequestParam("password") String password, Model model) {	
		List<cars> car= carrepository.findAll();
		model.addAttribute("car", car);
		System.out.println(car);
		
		if(username.isEmpty()) {
			return "ErrorPage";
		}else {
			model.addAttribute("username", username);
			return "homepage";
		}
	}
	
	
	@RequestMapping("/register")
	public String RegistrationPage() {
		return "registerPage";
	}
	
	@RequestMapping("/registeruser")
	public String ChangeMicroService(@RequestParam("username") String username, 
			@RequestParam("password1") String password1, @RequestParam("password2") String password2, Model model) {
		System.out.println("Registering the user using the Register MicroService");
		if(password1.equals(password2)) {
			resttemplate.getForObject("http://localhost:8081/register-user/"+username+"/"+password1,String.class);
			model.addAttribute("Registration Success","Successfully registered");
		}else {
			model.addAttribute("registrationError","password not same!!!");
		}
		System.out.println("Returned back to the Login Micro Service");
		return "registerSuccessful";
	}
	
	
	@GetMapping("/showFormforAdd")
	public String FormForAdd(Model model) {
		cars thecars=new cars();
		model.addAttribute("car", thecars);
		return "addCars";
	}
	
	
	@PostMapping("/saveCars")
	public String saveCars(@ModelAttribute("car") cars thecar) {
		carrepository.save(thecar);
		return "SuccessCar";
		
		
	}
	
	@GetMapping("/showFormForUpdate")
	public String updateCars(@RequestParam("id") int id,Model model) {
		Optional<cars> thecar=carrepository.findById(id);
		model.addAttribute("car", thecar);
		return "addCars";
	}
}
