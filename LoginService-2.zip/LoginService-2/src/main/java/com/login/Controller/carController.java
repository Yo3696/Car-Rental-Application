package com.login.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.login.Model.cars;
import com.login.Repository.carRepository;

@Controller
public class carController {
	

	@Autowired
	private carRepository carrepository;
	
	
	@GetMapping("/delete")
	public String deletecar(@RequestParam("id") int id,Model model) {
		List<cars> car= carrepository.findAll();
		model.addAttribute("car", car);
		carrepository.deleteById(id);
		return "deletedVehicle";
	}
	
}
