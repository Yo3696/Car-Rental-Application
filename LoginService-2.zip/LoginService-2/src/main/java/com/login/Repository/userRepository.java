package com.login.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.login.Model.user;

public interface userRepository extends JpaRepository<user, Integer> {
	
	user findByName(String username);
}
