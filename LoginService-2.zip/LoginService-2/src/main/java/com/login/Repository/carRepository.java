package com.login.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.login.Model.cars;

@Repository
public interface carRepository extends JpaRepository<cars, Integer> {

}
